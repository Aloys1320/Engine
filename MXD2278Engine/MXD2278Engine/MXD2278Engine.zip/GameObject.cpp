#include "GameObject.h"
#include "ShaderManager.h"
#include <math.h>

void GameObject::updateModel(GLuint program,float time)
{
	moveModel(time);

	glProgramUniformMatrix4fv(program, glGetUniformLocation(program, "worldLoc"), 1, GL_FALSE, &transform.worldTrans[0][0]);
	model.render();
}

void GameObject::moveModel(float time)
{
	//Calc Forces
	rigidBody.velocity += rigidBody.velocityChange;
	rigidBody.force += (rigidBody.velocity*rigidBody.mass);

	//Limit a Game Objects max speed (default max speed is .025)
	//if (glm::length2(rigidBody.force)> rigidBody.maxSpeed) {
	//	rigidBody.force = glm::normalize(rigidBody.force);
	//	rigidBody.force *= rigidBody.maxSpeed;
	//}
	//rigidBody.force = glm::max(rigidBody.force, rigidBody.maxSpeed, rigidBody.maxSpeed);
	//Update the objects location
	transform.location += ((rigidBody.force) * (time/60));
	/*if (rigidBody.mass >= 1) {
		std::cout << "x: " <<rigidBody.force.x<< "y:" << rigidBody.force.y << "z: " << rigidBody.force.z << std::endl;
	}*/

	//Reset the applied force (doesnt reset the velocity, that will slowly dwindle down below)
	rigidBody.force = glm::vec3(0);

	//Apply Friction (x axis)
	//if (glm::length2(rigidBody.velocity)>0)
	rigidBody.velocity = rigidBody.velocity * .9f;

	//std::cout << "Vx: " << rigidBody.velocity.x << "Vy:" << rigidBody.velocity.y << "Vz: " << rigidBody.velocity.z << std::endl;

	//Actual Movment
	glm::mat4 translate;
	translate = { 1, 0, 0, transform.location.x,
		0, 1, 0, transform.location.y,
		0, 0, 1, transform.location.z,
		0, 0, 0, 1 };
	transform.worldTrans = 
		glm::scale(transform.size) *
		glm::yawPitchRoll(transform.rotation.y, transform.rotation.x, transform.rotation.z) *
		translate;

}

bool GameObject::collidesWith(const GameObject & other)
{
	//If either has no collider
	if(collider==colliderless||other.collider==colliderless)
		return false;
	
	//If Both have sphere
	else if (collider == sphere&&other.collider == sphere) {
		glm::vec3 dist = transform.location - other.transform.location;
		//Get length of distance between them and check if it is larger than the radii sum
		if (pow(dist.x, 2) + pow(dist.y, 2) + pow(dist.z, 2) > pow((transform.size.x + other.transform.size.x),2))
			return false;
	}

	//If both are aabb based, check each axis
	else if(collider==axisAlignedBoundingBox&&other.collider==axisAlignedBoundingBox){
		if ((transform.location.x - other.transform.location.x) > (transform.size.x + other.transform.size.x)) // X-Axis Check
			return false;
		if ((transform.location.y - other.transform.location.y) > (transform.size.y + other.transform.size.y)) // Y-Axis Check
			return false;
		if ((transform.location.z - other.transform.location.z) > (transform.size.z + other.transform.size.z)) // Z-Axis Check
			return false;
	}

	//No Collisions detected, return true
	return true;
}

GameObject::GameObject()
{
	rigidBody.maxSpeed = .25;
	rigidBody.velocityChange = glm::vec3(0);

}


GameObject::~GameObject()
{
}
